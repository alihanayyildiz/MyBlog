<div class="sidebar-frame">
<div class="sidebar-adv" style="<?php echo get_option('my_sidebarboxadv_display');?>">
	    <?php echo get_option('my_sidebarbox_advert');?>
</div>
<div class="sidebar-posts" style="<?php echo  get_option('my_sidebar_cat');?>">
    <div class="sidebar-title">
        <h3>POPÜLER YAZILAR</h3><hr>
    </div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <?php $result = $wpdb->get_results("SELECT comment_count,ID,post_title FROM $wpdb->posts ORDER BY comment_count DESC LIMIT 0 , 5");
                foreach ($result as $post) {
                setup_postdata($post);
                $postid = $post->ID;
                $title = $post->post_title;
                $commentcount = $post->comment_count;
                if ($commentcount != 0) { ?>     
                <div class="row" style="margin-bottom:10px; margin-top:10px; padding-left:20px; padding-right:20px;">
                <div class="col-md-12 col-sm-12 col-xs-12" style=" border-bottom:1px solid #ccc; padding:0px; padding-bottom:10px;">
                <div class="col-md-4 col-sm-3 col-xs-4" style="padding-left:10px;">
                    <div class="sidebar-img">
                        <a href="<?php echo get_permalink($postid); ?>">
                        <?php
                        if (has_post_thumbnail()) { the_post_thumbnail('anasyfa',array('class'=>'makale-resim'));}
                        else{ ?>
                        <img src="<?php bloginfo("template_url"); ?>/img/no-image.jpg" alt="Teknolojiye Dair Herşey..."> <?php } ?>
                        </a>
                    </div>
                </div>
                <div class="col-md-8 col-sm-9 col-xs-8" style="padding:0px; padding-right:5px;">
                    <div class="sidebar-img-title">
                        <a href="<?php echo get_permalink($postid); ?>"><?php kisa_baslik(50); ?>...</a>
                    </div>
                </div>
                </div>
                </div>
                <?php }}?>
        </div>
    </div>
</div>  


    <div class="sidebar-posts" style="<?php echo  get_option('my_sidebar_cat');?>">
        <div class="sidebar-title"><h3>KATEGORİLER</h3><hr></div>
        <ul>
            <?php wp_list_cats('sort_column=namae&hierarchical=0'); ?>
        </ul>
    </div>
    <div class="sidebar" style="<?php echo get_option('my_sidebar');?>">
        <ul>
		<?php if( !function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar')) : ?>
		<?php endif; ?>
        </ul>
    </div>
    <div class="sidebar-vertical-adv" style="<?php echo get_option('my_sidebarverticaladv_display');?>">
        <?php echo get_option('my_sidebarvertical_advert');?>
    </div>
