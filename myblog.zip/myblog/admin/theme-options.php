<?php

add_action('init','of_options');

if (!function_exists('of_options')) {
function of_options(){
	
// VARIABLES
$themename = get_theme_data(STYLESHEETPATH . '/style.css');
$themename = $themename['Name'];
$shortname = "my";

// Populate OptionsFramework option in array for use in theme
global $of_options;
$of_options = get_option('of_options');

$GLOBALS['template_path'] = OF_DIRECTORY;

//Access the WordPress Categories via an Array
$of_categories = array();  
$of_categories_obj = get_categories('hide_empty=0');
foreach ($of_categories_obj as $of_cat) {
    $of_categories[$of_cat->cat_ID] = $of_cat->cat_name;}
$categories_tmp = array($of_categories);    
       
//Access the WordPress Pages via an Array
$of_pages = array();
$of_pages_obj = get_pages('sort_column=post_parent,menu_order');    
foreach ($of_pages_obj as $of_page) {
    $of_pages[$of_page->ID] = $of_page->post_name; }
$of_pages_tmp = array($of_pages);       

// Image Alignment radio box
$options_thumb_align = array("alignleft" => "Left","alignright" => "Right","aligncenter" => "Center"); 

// Image Links to Options
$options_image_link_to = array("image" => "The Image","post" => "The Post");  

//Stylesheets Reader
$alt_stylesheet_path = OF_FILEPATH . '/styles/';
$alt_stylesheets = array();

if (is_dir($alt_stylesheet_path) ) {
    if ($alt_stylesheet_dir = opendir($alt_stylesheet_path) ) { 
        while ( ($alt_stylesheet_file = readdir($alt_stylesheet_dir)) !== false ) {
            if(stristr($alt_stylesheet_file, ".css") !== false) {
                $alt_stylesheets[] = $alt_stylesheet_file;
            }
        }    
    }
}

//More Options
$uploads_arr = wp_upload_dir();
$all_uploads_path = $uploads_arr['path'];
$all_uploads = get_option('of_uploads');
$other_entries = array("Select a number:","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19");
$body_repeat = array("no-repeat","repeat-x","repeat-y","repeat");
$body_pos = array("top left","top center","top right","center left","center center","center right","bottom left","bottom center","bottom right");

// Set the Options Array
$imgurl =  OF_DIRECTORY . '/admin/images/';

$options = array();

// General
$options[] = array( "name" => "Genel Ayarlar",
                    "type" => "heading");					

$options[] = array( "name" => "Logo",
					"desc" => "Lütfen Sitenizin Sol Üst Köşesinde Görüntülenecek Olan Logonuzu Yükleyiniz...(İdeal Boyutlar 140X50 Pixel)",
					"id" => $shortname."_logo",
					"std" => "",
					"type" => "upload");

$options[] = array( "name" => "Kullanılacak Logo Boyutu",
                    "desc" => "Logonuzun Genişliğini Belirleyebilirsiniz...",
                    "id" => $shortname."_logo_width",
                    "std" => "excerpt",
                    "type" => "radio",
                    "options" => array('width:140px' => 'Genişlik 140 Pixel', 'width:170px' => 'Genişlik 170 Pixel'));

$options[] = array( "name" => "Site Favicon",
					"desc" => "Sitenizde Kullanacağınız Favicon'u Yüklemelisiniz... (Favicon 16 X 16 Pixel Boyutlarında Olmalıdır)",
					"id" => $shortname."_favicon",
					"std" => "",
					"type" => "upload");

$options[] = array( "name" => "Sidebar Ayarları",
	                    "type" => "heading");

$options[] = array( "name" => "Wordpress Sidebar Alanını Gizle/Göster",
                    "desc" => "Wordpress Panelinden Sidebar Düzenlemek İçin Bu Alanı Aktif Etmelisiniz. Eğer Aktif Etmezseniz Tema İçeriğinde Yer Alan Sidebar'ı ",
                    "id" => $shortname."_sidebar",
                    "std" => "excerpt",
                    "type" => "radio",
                    "options" => array('display:block' => 'Göster', 'display:none' => 'Gizle'));

$options[] = array( "name" => "Popüler Konular Alanını Gizle/Göster",
                    "desc" => "Temanın Kendi İçerisinde Gelen Popüler Konular Alanını Açabilir ve Kapatabilirsiniz...",
                    "id" => $shortname."_sidebar_pop",
                    "std" => "excerpt",
                    "type" => "radio",
                    "options" => array('display:block' => 'Göster', 'display:none' => 'Gizle'));

$options[] = array( "name" => "Kategoriler Alanını Gizle/Göster",
                    "desc" => "Temanın Kendi İçerisinde Gelen Kategoriler Alanını Açabilir ve Kapatabilirsiniz...",
                    "id" => $shortname."_sidebar_cat",
                    "std" => "excerpt",
                    "type" => "radio",
                    "options" => array('display:block' => 'Göster', 'display:none' => 'Gizle'));
//Slider
$options[] = array( "name" => "Slider Ayarları",
                    "type" => "heading");

$options[] = array( "name" => "Slider Alanını Gizle/Göster",
                    "desc" => "Slider Alanını Açabilir ve Kapatabilirsiniz...",
                    "id" => $shortname."_sliderdisplay",
                    "std" => "excerpt",
                    "type" => "radio",
                    "options" => array('display:block' => 'Göster', 'display:none' => 'Gizle'));
// Social
$options[] = array( "name" => "Sosyal Medya",
					"type" => "heading");

$options[] = array( "name" => "Facebook",
                    "desc" => "Lütfen Facebook Kullanıcı Adınızı (https://www.facebook.com/kullanıcıadınız) Şeklinde Girin...",
                    "id" => $shortname."_facebook",
                    "std" => "",
                    "type" => "text");

$options[] = array( "name" => "Twitter",
					"desc" => "Lütfen Twitter Kullanıcı Adınızı (https://www.twitter.com/kullanıcıadınız) Şeklinde Girin...",
					"id" => $shortname."_twitter",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => "YouTube",
                    "desc" => "Lütfen Youtube Kullanıcı Adınızı (https://www.youtube.com/kullanıcıadınız) Şeklinde Girin...",
                    "id" => $shortname."_youtube",
                    "std" => "",
                    "type" => "text");

$options[] = array( "name" => "Google +",
                    "desc" => "Lütfen Google+ Kullanıcı Adınızı (https://www.plus.google.com/kullanıcıadınız) Şeklinde Girin...",
                    "id" => $shortname."_googleplus",
                    "std" => "",
                    "type" => "text");

$options[] = array( "name" => "İnstagram",
                    "desc" => "Lütfen İnstagram Kullanıcı Adınızı (https://www.instagram.com/kullanıcıadınız) Şeklinde Girin...",
                    "id" => $shortname."_instagram",
                    "std" => "",
                    "type" => "text");

$options[] = array( "name" => "Linkedin",
                    "desc" => "Lütfen Linkedin Kullanıcı Adınızı (https://www.linkedin.com/in/kullanıcıadınız) Şeklinde Girin...",
                    "id" => $shortname."_linkedin",
                    "std" => "",
                    "type" => "text");

// Advertisement
$options[] = array( "name" => "Mobil Reklam Alanı",
                    "type" => "heading");

$options[] = array( "name" => "Ana Sayfa Mobil Reklam Alan(320X100)",
                   "desc" => "Ana Sayfada Bulunan Mobil Reklam Alanını Görüntülemek veya Kapatmak İsterseniz Bu Alanı Kullanabilirsiniz",
                    "id" => $shortname."_advmobilehome",
                    "std" => "excerpt",
                    "type" => "radio",
                    "options" => array('display:block' => 'Reklam Alanını Aç', 'display:none' => 'Reklam Alanını Kapat'));

$options[] = array( "name" => "Ana Sayfa Mobil Reklam Alanı Kodu(320X100)",
                    "desc" => "Lütfen Reklam Kodunuzu Buraya Yapıştırın... Not : Resim İçin img src=resimadresiniz Şeklinde KullanmalısınızScript Taglarındaki Adsense Kodları Direkt Olarak Kullanabilirsiniz...",
                    "id" => $shortname."_advhomecode",
                    "std" => "",
                    "type" => "textarea");

$options[] = array( "name" => "İç Sayfa Üst Reklam Alanı (320X100)",
                    "desc" => "İç Sayfada Bulunan Mobil Reklam Alanını Görüntülemek veya Kapatmak İsterseniz Bu Alanı Kullanabilirsiniz",
                    "id" => $shortname."_advsinglemobile",
                    "std" => "excerpt",
                    "type" => "radio",
                    "options" => array('display:block' => 'Reklam Alanını Aç', 'display:none' => 'Reklam Alanını Kapat'));

$options[] = array( "name" => "İç Sayfa Üst Reklam Alanı Kodu(320X100)",
                    "desc" => "Lütfen Reklam Kodunuzu Buraya Yapıştırın... Not : Resim İçin img src=resimadresiniz Şeklinde KullanmalısınızScript Taglarındaki Adsense Kodları Direkt Olarak Kullanabilirsiniz...",
                    "id" => $shortname."_advsinglecode",
                    "std" => "",
                    "type" => "textarea");

$options[] = array( "name" => "Reklam Alanı Ayarları",
					"type" => "heading");

$options[] = array( "name" => "Ana Sayfa Üst Kısım Geniş Reklam(970X250)",
                    "desc" => "Ana Sayfada Bulunan Geniş Reklam Alanını Görüntülemek veya Kapatmak İsterseniz Bu Alanı Kullanabilirsiniz",
                    "id" => $shortname."_advhomepage_display",
                    "std" => "excerpt",
                    "type" => "radio",
                    "options" => array('display:block' => 'Reklam Alanını Aç', 'display:none' => 'Reklam Alanını Kapat'));

$options[] = array( "name" => "Ana Sayfa Üst Kısım Reklam Kodu(970x250)",
                    "desc" => "Lütfen Reklam Kodunuzu Buraya Yapıştırın... Not : Resim İçin img src=resimadresiniz Şeklinde KullanmalısınızScript Taglarındaki Adsense Kodları Direkt Olarak Kullanabilirsiniz...",
                    "id" => $shortname."_homepageadv",
                    "std" => "",
                    "type" => "textarea");

$options[] = array( "name" => "Sidebar Üst Reklam Alanı(300X250)",
                    "desc" => "Sidebar Kısmında Bulunan Kare Reklam Alanını Görüntülemek veya Kapatmak İsterseniz Bu Alanı Kullanabilirsiniz",
                    "id" => $shortname."_sidebarboxadv_display",
                    "std" => "excerpt",
                    "type" => "radio",
                    "options" => array('display:block' => 'Reklam Alanını Aç', 'display:none' => 'Reklam Alanını Kapat'));

$options[] = array( "name" => "Sidebar Üst Reklam Kodu(300X250)",
                    "desc" => "Lütfen Sidebar Rekilam Kodunuzu Buraya Yapıştırın...  Not : Resim İçin img src=resimadresiniz Şeklinde Kullanmalısınız Script Taglarındaki Adsense Kodları Direkt Olarak Kullanabilirsiniz...",
                    "id" => $shortname."_sidebarbox_advert",
                    "std" => "",
                    "type" => "textarea");

$options[] = array( "name" => "Sidebar Alt Dikey Reklam Alanı(300X600)",
                    "desc" => "Sidebar Kısmında Bulunan Dikey Reklam Alanını Görüntülemek veya Kapatmak İsterseniz Bu Alanı Kullanabilirsiniz",
                    "id" => $shortname."_sidebarverticaladv_display",
                    "std" => "excerpt",
                    "type" => "radio",
                    "options" => array('display:block' => 'Reklam Alanını Aç', 'display:none' => 'Reklam Alanını Kapat'));

$options[] = array( "name" => "Sidebar Alt Dikey Reklam(300X600)",
                    "desc" => "Lütfen Sidebar Alanındaki Dikey Reklam Kodunuzu Buraya Yapıştırın...  Not : Resim İçin img src=resimadresiniz Şeklinde Kullanmalısınız Script Taglarındaki Adsense Kodları Direkt Olarak Kullanabilirsiniz...",
                    "id" => $shortname."_sidebarvertical_advert",
                    "std" => "",
                    "type" => "textarea");

$options[] = array( "name" => "Single(Yazı) Sayfası Reklam Alanı(970X250)",
                    "desc" => "Yazı Sayfasının Üst Kısmındaki Geniş Reklam Alanını Görüntülemek veya Kapatmak İsterseniz Bu Alanı Kullanabilirsiniz",
                    "id" => $shortname."_singleadv_display",
                    "std" => "excerpt",
                    "type" => "radio",
                    "options" => array('display:block' => 'Reklam Alanını Aç', 'display:none' => 'Reklam Alanını Kapat'));

$options[] = array( "name" => "Single(Yazı) Sayfası Reklam Kodu(970X250)",
                    "desc" => "Lütfen Single(Yazı) Sayfasındaki Üst Reklam Alanı Reklam Kodunuzu Buraya Yapıştırın...  Not : Resim İçin img src=resimadresiniz Şeklinde Kullanmalısınız Script Taglarındaki Adsense Kodları Direkt Olarak Kullanabilirsiniz...",
                    "id" => $shortname."_singleadv_advert",
                    "std" => "",
                    "type" => "textarea");
// Analytics
$options[] = array( "name" => "Analytics Kodu",
					"type" => "heading");     
					
$options[] = array( "name" => "Google Analytics İzleme Kodu",
					"desc" => "Google Tarafından Size Verilen Kodu Bu Alana Yapıştırarak Analytics İle Sitenizin Detaylı İzlemesini Gerçekleştirebilirsiniz ",
					"id" => $shortname."_analytics",
					"std" => "",
					"type" => "textarea");

// SEO
$options[] = array( "name" => "SEO Ayarları",
                    "type" => "heading");					

$options[] = array( "name" => "Description",
					"desc" => "Sitenin Açıklamaları Girilmelidir...",
					"id" => $shortname."_seo_description",
					"std" => "Site Hakkında Bilgi...",
					"type" => "text");

$options[] = array( "name" => "Keywords",
					"desc" => "Sitenin Anahtar Kelimeleri Girilmelidir...",
					"id" => $shortname."_seo_keywords",
					"std" => "teknoloji, web, wordpress, myblog, seo",
					"type" => "text");

$options[] = array( "name" => "Footer Ayarları",
                    "type" => "heading");

$options[] = array( "name" => "Footer Üst Kısım Yazısı",
                    "desc" => "Footer Alanında Görünen Yazı Belirlenmelidir...",
                    "id" => $shortname."_footer_top_write",
                    "std" => "",
                    "type" => "text");

$options[] = array( "name" => "Footer Orta Kısım Yazısı",
                    "desc" => "Footer Alanında Görünen Yazı Belirlenmelidir...",
                    "id" => $shortname."_footer_write",
                    "std" => "",
                    "type" => "text");

$options[] = array( "name" => "Footer Üst Kısmını Gizle/Göster",
                    "desc" => "Footer Üst Kısmını Gizleyip Gösterebilirsiniz...",
                    "id" => $shortname."_footer_top_display",
                    "std" => "excerpt",
                    "type" => "radio",
                    "options" => array('display:block' => 'Göster', 'display:none' => 'Gizle'));

$options[] = array( "name" => "Footer Alt Copyright Yazısı",
                    "desc" => "Footer Alanında Görünen Yazı Belirlenmelidir...",
                    "id" => $shortname."_footer_copyright",
                    "std" => "",
                    "type" => "text");

$options[] = array( "name" => "Footer Copyright Alanını Gizle/Göster ",
                    "desc" => "Footer Copyright Alanını Gizleyip Gösterebilirsiniz...",
                    "id" => $shortname."_footer_copy_display",
                    "std" => "excerpt",
                    "type" => "radio",
                    "options" => array('display:block' => 'Göster', 'display:none' => 'Gizle'));

update_option('of_template',$options);
update_option('of_themename',$themename);   
update_option('of_shortname',$shortname);

}
}
?>