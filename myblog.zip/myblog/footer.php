<div class="footer-top" style="<?php echo get_option('my_footer_top_display')?>">
        <div class="container">
            <div class="row">
                <h4 class="footer-title"><?php echo get_option('my_footer_top_write')?></h4>
                <p class="footer-write"><?php echo get_option('my_footer_write')?></p>
                <div class="social-media">
                    <div class="container">
                        <a href="<?php echo get_option('my_facebook')?>" target="_blank" class="facebook">
                            <div class="col-md-2 col-sm-6 col-xs-12" id="facebook">
                                <i class="fab fa-facebook"></i>
                                &nbsp;FACEBOOK
                            </div>
                        </a>
                        <a href="<?php echo get_option('my_twitter')?>" target="_blank" class="twitter">
                            <div class="col-md-2 col-sm-6 col-xs-12" id="twitter">
                                <i class="fab fa-twitter"></i>
                                &nbsp;TWITTER
                            </div>
                        </a>
                        <a href="<?php echo get_option('my_youtube')?>" target="_blank" class="youtube">
                            <div class="col-md-2 col-sm-6 col-xs-12" id="youtube">
                                <i class="fab fa-youtube"></i>
                                &nbsp;YOUTUBE
                            </div>
                        </a>
                        <a href="<?php echo get_option('my_googleplus')?>" target="_blank" class="google">
                            <div class="col-md-2 col-sm-6 col-xs-12" id="google">
                                <i class="fab fa-google-plus-square"></i>
                                &nbsp;GOOGLE+
                            </div>
                        </a>
                        <a href="<?php echo get_option('my_instagram')?>" target="_blank" class="instagram">
                            <div class="col-md-2 col-sm-6 col-xs-12" id="instagram">
                                <i class="fab fa-instagram"></i>
                                &nbsp;INSTAGRAM
                            </div>
                        </a>
                        <a href="<?php echo get_option('my_linkedin')?>" target="_blank" class="linkedin">
                            <div class="col-md-2 col-sm-6 col-xs-12" id="linkedin">
                                <i class="fab fa-linkedin"></i>
                                &nbsp;LINKEDIN
                            </div>
                        </a>
                </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom" style="<?php echo get_option('my_footer_copy_display')?>">
        <div class="container">
            <div class="row">
                <div class="footer-copyright">
                    <h6><?php echo get_option('my_footer_copyright');?></h6>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<script language="javascript" type="text/javascript" src="<?php bloginfo('template_url') ?>/main/toggle.js"></script>
<script defer src="https://use.fontawesome.com/releases/v5.0.9/js/all.js" integrity="sha384-8iPTk2s/jMVj81dnzb/iFR2sdA7u06vHJyyLlAd4snFpCl/SnyUjRrbdJsw1pGIl" crossorigin="anonymous"></script>