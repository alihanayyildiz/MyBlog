<?php get_header();?>
<div class="container">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12" >
            <div class="adv-single">
                <div class="adv-homepage" style="<?php echo get_option('my_singleadv_display');?>">
			        <?php echo get_option('my_singleadv_advert');?>
                </div>
            </div>
            <div class="adv-single-mobile">
                <div class="adv-mobile" style="<?php echo get_option('my_advsinglemobile');?>">
			        <?php echo get_option('my_advsinglecode');?>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
	<div class="row">
		<div class="breadcrumb-single">
			<ul>
				<li><a href="<?php bloginfo('url'); ?>">Ana Sayfa &nbsp;<i class="fa fa-caret-right"></i></a>&nbsp;</li>
				<li><?php the_category(' &nbsp;<i class="fa fa-caret-right"></i> '); ?>&nbsp;</li>
				<li><?php the_title(' &nbsp;<i class="fa fa-caret-right"></i> '); ?>&nbsp;</li>
			</ul>
		</div>
	</div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-9">
            <div class="single-post-img">
            <?php
            if (has_post_thumbnail()) { the_post_thumbnail('anasyfa',array('class'=>'makale-resim'));}
            else{ ?>
            <img src="<?php bloginfo("template_url"); ?>/img/no-image.jpg" alt="Teknolojiye Dair Herşey..."> <?php } ?>
        </div>
        <div class="col-md-12" id="single-info">
        <div class="single-post-title">
                <h1><?php the_title();?></h1>
            </div>
            <div class="col-md-8 col-sm-8 col-xs-8" id="user">
		        <?php echo get_avatar( get_the_author_meta('user_email') ); ?>
		        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                    <span class="user-name"><?php the_author(); ?></span>
		        <?php endwhile; endif; ?>
		        <?php echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . ' Önce Ekledi | ';?>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-4">
                <div class="post-views">
			        <?php setPostViews(get_the_ID()); ?>
                    <h5><i class="fa fa-eye"></i> <?php echo getPostViews(get_the_ID()); ?></h5>
                </div>
            </div>
            <div class="single-write">
	            <?php the_content(); ?>
            </div>
            
            <div class="tags">
                <b>ETİKETLER : </b> <?php the_tags(''); ?>
            </div>
            <div class="prev-next-post">
                <div class="col-md-6">
                    <h2><p>Önceki yazımız</p></h2>
			        <?php previous_post_link( '%link', '%title' ); ?>
                </div>
                <div class="col-md-6">
                    <h2><p>Sonraki Yazımız</p></h2>
			        <?php next_post_link( '%link', '%title' ); ?>
                </div>
            </div>
            <div class="col-md-12 col-sm-12 col-xs-12 benzer-yazilar">
                <?php
                    $categories = get_the_category($post->ID);
                    if ($categories) {
                    $category_ids = array();
                    foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;    
                    $args=array(
                        'category__in' => $category_ids,
                        'post__not_in' => array($post->ID),
                        'showposts'=>4, // Gösterilecek benzer yazı sayısı
                        'caller_get_posts'=>1
                    );
                        $my_query = new wp_query($args);
                        if( $my_query->have_posts() ) {
                        echo '<h3 style="margin-left:10px;">Benzer yazılar</h3><ul>';
                        while ($my_query->have_posts()) {
                        $my_query->the_post();
                ?>
                            <li>
                            <div class="col-md-3 col-sm-6 col-xs-12">
                                <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
                                <div class="benzer-yazi-resim">
                                <?php
	                            if (has_post_thumbnail()) { the_post_thumbnail('anasyfa',array('class'=>'makale-resim'));}
    	                        else{ ?>
                                <img src="<?php bloginfo("template_url"); ?>/img/no-image.jpg" alt="Teknolojiye Dair Herşey..."> <?php } ?>            
                                </div>
                                <div class="benzer-yazi-baslik">
                                    <a href="<?php the_permalink() ?>"><?php the_title(); ?></a>
                                </div>
                                </a>
                                </div>
                            </li>
                        <?php
                        }
                        echo '</ul>';
                    }
                    wp_reset_query();
                    }
                    ?>
            </div>
            <div class="comments">
		        <?php comments_template();?>
            </div>
        </div>
    </div>

        <div class="col-md-3">
            <div class="sidebar-single">
			    <?php get_sidebar();?>
            </div>
        </div>
    </div>
</div>
</div>
<?php get_footer();?>
