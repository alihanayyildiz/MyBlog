<?php get_header(); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
                <div class="not-found">
                <h4>ARADIĞINIZ SAYFAYI BULAMADIK<br>ANA SAYFAYA <a href="<?php bloginfo('url');?>">BURADAN</a> DÖNEBİLİRSİNİZ</h4>
                </div>
            </div>
            </div>
        </div>
<?php get_footer(); ?>
