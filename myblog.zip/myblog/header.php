<!doctype html>
<html lang="en">
<head>
    <meta charset="<?php bloginfo( 'charset'); ?>">
    <title><?php wp_title('', true, 'right');?> <?php bloginfo('name'); ?></title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta name="keywords" content="<?php echo get_option('my_seo_keywords');?>">
    <meta name="description" content="<?php echo get_option('my_seo_description');?>">
    <link rel="icon" href="<?php echo get_option('my_favicon');?>" type="image/x-icon" />
    <link rel="stylesheet" href="<?php bloginfo('template_url') ?>/style.css">
    <link rel="stylesheet" href="<?php bloginfo('template_url') ?>/reset.css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">
    <script language="javascript" type="text/javascript" src="<?php bloginfo('template_url') ?>/main/slider.js"></script>
    <?php echo get_option('my_analytics');?>
</head>
<body style="background: #f5f5f5">
<div class="site-header">
    <div class="container">
        <div class="row no-padding">
        <div class="col-md-2 col-sm-12 col-xs-12 no-padding" >
                <div class="logo-align">
                    <div class="logo" style="<?php echo get_option('my_logo_width');?>">
                    <a href="<?php bloginfo('url');?>">
                        <?php
                        if (get_option('my_logo')=='') {
                        echo '<img src="'; bloginfo('template_url');  echo '/img/logo.png" width="100%" height="100%" alt="Logo"/>';
                        }
                        else {
                        echo '<img src="'.get_option('my_logo'). '" width="100%" height="100%" alt="Logo"/> ';
                        }
                        ?>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-7 col-sm-12 col-xs-12 no-padding">
                <div id='cssmenu'>
	                <?php wp_nav_menu(array('theme_location' => 'wpmenu1', 'container' => '')); ?>
                </div>
            </div>
            <div class="col-md-3 col-sm-12 col-xs-12 no-padding">
                <div id='search-box'>
                    <form action='<?php echo home_url( '/' ); ?>' id='search-form' method='get'>
                        <input id='search-text' name='s' placeholder='ARA' type='text'/>
                        <button id='search-button' type='submit'>
                            <span class="fa fa-search"></span>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>