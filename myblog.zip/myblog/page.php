<?php get_header();?>
<div class="container">
    <div class="row">
        <div class="col-md-9 col-offset-3">
            <div class="page-post-title">
                <h1><?php the_title();?></h1>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row no-padding">
        <div class="col-md-9" id="page-left-options">
	        <?php
	        if (has_post_thumbnail()) { the_post_thumbnail('anasyfa',array('class'=>'makale-resim'));}
	        else{ ?> <?php } ?>
	        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
            <div class="col-md-12" id="page-info">
                <div class="page-write">
		            <?php the_content(); ?>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="sidebar-page">
		        <?php get_sidebar();?>
            </div>
        </div>
	    <?php endwhile; endif; ?>
    </div>
</div>
</div>
<?php get_footer();?>
