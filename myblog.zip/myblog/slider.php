<div class="slider">
    <div class="container">
        <div class="row no-padding">
            <div class="slider-container">
                <div class="col-md-7 col-sm-12 col-xs-12 no-padding" >
                    <div id="jssor_1" class="jssor1">
                        <div data-u="loading" class="loading">
                            <div class="slider-options"></div>
                        </div>
                        <div data-u="slides" class="slides">
							<?php if (have_posts()) : ?>
								<?php $slider = new WP_Query("'showposts=10&orderby=date&cat=1'"); while($slider ->have_posts()) : $slider ->the_post();?><!--cat=1 kısmına göstermek istediğiniz kategori id'sini girin-->
                                    <div data-p="225.00" class="slide-img">
                                        <a href="<?php the_permalink(); ?>"> <?php the_post_thumbnail( 'full' );?>
	                                        <?php if (has_post_thumbnail()) { the_post_thumbnail('anasyfa',array('class'=>'makale-resim'));}
	                                        else{ ?>
                                                <img src="<?php bloginfo("template_url"); ?>/img/no-image.jpg" alt="Teknolojiye Dair Herşey..."> <?php } ?>
                                            <div class="slide-title">
                                                <h1 style="font-size: 30px"><?php the_title(); ?></h1>
                                            </div>
                                        </a>
                                    </div>
								<?php endwhile; ?>
							<?php endif; ?>
                        </div>
                        <div data-u="navigator" class="jssorb05" style="bottom:16px;right:6px;" data-autocenter="1">
                            <div data-u="prototype"></div>
                        </div>
                        <span data-u="arrowleft" class="jssora22l" data-autocenter="2"></span>
                        <span data-u="arrowright" class="jssora22r" data-autocenter="2"></span>
                    </div>
                    <script>
                        jssor_1_slider_init();
                    </script>
                </div>
            </div>

                <!--Slider Right Box Top Options-->
                <div class="slide-right-box" style="display:block;">
                <div class="col-md-5 no-padding" id="slide-right-box">
	                <?php if (have_posts()) : ?>
		                <?php $rightbox = new WP_Query("'&cat=1&showposts=1'"); while($rightbox ->have_posts()) : $rightbox ->the_post();?><!--cat=2 kısmına göstermek istediğiniz kategori id'sini girin-->
                                <div class="col-md-12 col-sm-4 col-xs-4">
                                    <div class="right-slide-box-img">
                                        <a href="<?php the_permalink(); ?>">
											<?php if (has_post_thumbnail()) { the_post_thumbnail('anasyfa',array('class'=>'makale-resim'));}
											else{ ?>
                                                <img src="<?php bloginfo("template_url"); ?>/img/no-image.jpg" alt="Teknolojiye Dair Herşey..."> <?php } ?>
                                            <div class="slide-top-category"><div class="slide-top-cat"><span><?php the_title(); ?></span></div></div>
                                        </a>
                                    </div>
                                </div>
		                <?php endwhile; ?>
	                <?php endif; ?>
                </div>
                <!--Slider Right Box Borrom Options-->
                <div class="col-md-5 no-padding" id="slide-right-box">
	                <?php if (have_posts()) : ?>
		                <?php $rightbox = new WP_Query("'&cat=1&showposts=2'"); while($rightbox ->have_posts()) : $rightbox ->the_post();?><!--cat=3 kısmına göstermek istediğiniz kategori id'sini girin-->
                                <div class="col-md-6 col-sm-4 col-xs-4">
                                    <div class="right-slide-box-options">
                                        <a href="<?php the_permalink(); ?>">
											<?php if (has_post_thumbnail()) { the_post_thumbnail('anasyfa',array('class'=>'makale-resim'));}
											else{ ?>
                                                <img src="<?php bloginfo("template_url"); ?>/img/no-image.jpg" alt="Teknolojiye Dair Herşey..."> <?php } ?>
                                            <div class="slide-box-category" > <div class="slide-cat"><span> <?php the_title(); ?></span></div></div>
                                        </a>
                                    </div>
                                </div>
						<?php endwhile; ?>
					<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
