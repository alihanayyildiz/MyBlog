<?php get_header(); ?>
    <div  style="<?php echo get_option('my_sliderdisplay');?>"><?php include("slider.php"); ?></div>
<div class="container">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="adv-home">
                <div class="adv-homepage" style="<?php echo get_option('my_advhomepage_display');?>">
                    <?php echo get_option('my_homepageadv');?>
                </div>
            </div>
            <div class="adv-home-mobile">
                <div class="adv-mobile" style="<?php echo get_option('my_advmobilehome');?>">
                    <?php echo get_option('my_advhomecode');?>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="post no-padding">
<div class="container">
    <div class="row">
        <div class="col-md-9 no-padding" id="post-margin">
            <div class="slider-margin">
	            <?php query_posts($query_string . ''); ?><!-- &cat= -gizlenecekkategoriid -->     <!--Slider'da Yayınlanan Kategorilerin ID'lerini Yazarak Gizlenmesini Sağlayabilirsiniz-->
                <?php if ( have_posts() ) : while ( have_posts() ) :the_post(); ?>
                <div class="col-md-4 col-sm-6 col-xs-12 no-padding" id="post-padding">
                    <div class="home-post-img">
                        <a href="<?php the_permalink(); ?>">
	                    <?php
	                    if (has_post_thumbnail()) { the_post_thumbnail('anasyfa',array('class'=>'makale-resim'));}
    	                else{ ?>
                            <img src="<?php bloginfo("template_url"); ?>/img/no-image.jpg" alt="Teknolojiye Dair Herşey..."> <?php } ?>
                        </a>
                    </div>
                    <div class="home-post-category">
                        <?php echo the_category(' , ') ?>
                    </div>
                    <div class="title">
                        <div class="home-post-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </div>
                    </div>
                </div>
                <?php endwhile; else: ?>
                <?php endif;?>
                </div>
                <div class="col-md-12" style="clear: both">
                    <div class="home-pages" style="margin-left:-20px ;">
    		            <?php page(); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12 col-xs-12" >
                <?php get_sidebar(); ?>
            </div>
        </div>
    </div>
</div>
    <?php get_footer();?>